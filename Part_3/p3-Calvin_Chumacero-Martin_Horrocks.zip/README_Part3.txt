#*******************************************************************************
# 
#	Project: Part 3
#	Team: Kashka Calvin, Nasley Chumacero-Martin, Matt Horrocks
#	CS482 Database Management Systems I
#
#	Description: This document contains the work allocation among team
#		members for Part 3 of the Project.				
#
#*******************************************************************************

Team Member Duties

Kashka C:
	* Meet with team members and decide if we will create an interface with a web development language
	  or if we will use Python to create an interface. If using Python, decide which module to use to create
	  the interface.
	* Design Tab #2 of the interface and add functionality to search a Scheduler System.
	* Design Tab #3 of the interface and add functionality to insert a new digital display into the database.
	* Assist with other tabs as needed and test their functionality.
	
Matt H:
	* Meet with team members and decide if we will create an interface with a web development language
	  or if we will use Python to create an interface. If using Python, decide which module to use to create
	  the interface.
	* Design Tab #5 of the interface and add functionality to update the fields of a digital display.
	* Help with the functions of Tab #1.
	* Final functinality testing and debugging.

Nasley C-M:
	* Meet with team members and decide if we will create an interface with a web development language
	  or if we will use Python to create an interface. If using Python, decide which module to use to create
	  the interface.
	* Create the original login window and base design for the database window interaction (tab menus).
	* Design Tab #1 and add functionality to display all digital displays and each model information.
	* Design Tab #4 and add functionality to delete digital displays from the database.
	